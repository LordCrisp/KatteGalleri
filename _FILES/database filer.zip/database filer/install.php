<?php

$includePath=$_SERVER["DOCUMENT_ROOT"];

require_once $includePath.'/assets/source/databaseFunctions.php';


if(empty($_GET)){
   // show database selection
    
$databases=ShowDatabases("127.0.0.1", "root", "");

foreach ($databases as $databaseName){
   echo '<a href="install.php?selectedDatabase='.$databaseName.'">'.$databaseName.'</a><br><br>'; 
   
   //getUser("Rikki");
   
   
}

}
else{
     // install table in selected database
    
    $mySelectedDatabase=$_GET["selectedDatabase"];
   
     installTable($mySelectedDatabase,"127.0.0.1","root","");
    header('Location: http://kattegalleriet.dev/index.php');
}

?>


