<?php


//--------------------------------------------------------------------------
// checker for @ og . i email 

function verifyEmail($myMail){
    $error=1;
    
    if (strpos($myMail,'@') == false) { 
 $error=0;
}

   if (strpos($myMail,'.') == false) { 
 $error=0;
}
return $error;

}

//--------------------------------------------------------------------------
// stripper for tags og trimmer white space i start og slut 
function secureName($myName){
   
    // trim strips whitespace
    // strip tags strips all tags
  
 
  $myName=strip_tags(trim($myName));

return $myName;

}



//--------------------------------------------------------------------------
// funktionen getUsers i databaseFunktioner returnerer brugbar array til $userDataArray

function userView($offset,$userCount,$userDataArray,$showPass,$showEmail){
    
    
// error trapping
// 
 if(gettype ($userDataArray)!="array" ){
        
return false;
    }
    
    
   $error=false;
   
    if(gettype ($userDataArray[0])!="array" ){
        
 $error=true;
    }
    
    
    
    
   if($error){
       return false;
       
   } 
  
    
// check offset
if( $offset>count($userDataArray)){
    $offset=count($userDataArray)-$userCount;
}

if($offset<0){
    $offset=0;
}



$endOffset=$offset+$userCount;

// check end offset
if( $endOffset>count($userDataArray)){
    $endOffset=count($userDataArray);
}


echo '<table>';
// heads
 echo '<tr><th>User name</th>';
 
if($showPass){
      echo '<th>Password</th>';
     }
      echo '<th>Full name</th>';
     if($showEmail){
        echo '<th>Email</th>';
      }
      echo '<th>User type</th>';
         echo '</tr>';
         
         // end heads

//loop gennem data
for($i=$offset;  $i<$endOffset;  $i++){
   
    $user=$userDataArray[$i];
   
    //row
    echo '<tr >';
    
     echo '<td ">'. $user["username"]."</td>";
     
     if($showPass){
      echo "<td>". $user["password"]."</td>";
     }
     
      echo "<td>". $user["full_name"]."</td>";
      
      if($showEmail){
       echo "<td>". $user["email"]."</td>";
      }
        echo "<td>". $user["user_type"]."</td>";
     
    
    //slut row
    echo "</tr>";
}
// efter loop
echo"</table>";
}
 


?>