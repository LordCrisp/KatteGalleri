<?php

//-------------------------------------------------------------------------
// returns array of users in database
function getUsers(){
    // gimmi link
    $link=createLink("127.0.0.1","root","","test");
    
    if($link){
     
        // jeg er connected til database
        $query = "SELECT * FROM userdata";
       


$result = mysqli_query($link,$query)or die(mysqli_error());


$num_row = mysqli_num_rows($result);

if($num_row>0){
//Get data and put it in array
    
           $userData=[];
            
        foreach ($result as $row) {
            //echo $row["username"];
            $userData[]=$row;
        }

return $userData;
        
    }
    else
    {
        // ingen data i result
        return false;
    }
    }
    
    else
    {
        //echo "link error";
        return false;
    }
        mysqli_close($link);  
}

//-------------------------------------------------------------------------
// check for user exists return false if user does not exists

function checkForUser($myNameToCheck){
    
    if(getUser($myNameToCheck)){
       return 1; 
    }
    else{
        return 0;
    }
}

//-------------------------------------------------------------------------
// creates a new user with info

function createUser($username,$password,$fullname,$email,$usertype){
    
        $sql = 'INSERT INTO userdata (username, password,full_name,email,user_type) VALUES ("'.

         $username.'","'.
            
        $password.'","'.
         $fullname.'","'.
        $email.'","'.
         $usertype.'")';

        
         $link=createLink("127.0.0.1","root","","test");
if ($link->query($sql) === TRUE) {
    echo "New crazy cat lady: ".$username." inserted successfully<br>";
    return 1;
} else {
    
    echo "Error: " . $sql . "<br>" . $link->error.'<br><br>';
    return 0;
}  
   mysqli_close($link);    
}

//-------------------------------------------------------------------------
// returns user data by user name

function getUser($userName){
    // gimmi link
    $link=createLink("127.0.0.1","root","","test");
    
    if($link){
      
        $query = "SELECT * FROM userdata WHERE username = '$userName'";
        //echo $query."<br>";


$result = mysqli_query($link,$query)or die(mysqli_error());

//echo'we are alive<br>';

$num_row = mysqli_num_rows($result);
//print_r($result);

$row=mysqli_fetch_array($result);

if($num_row==1){
//print_r($row);

    //echo "password: ".$row["password"];
    return $row;
}
else{
    //echo "nope";
    return 0;
}
        
    }
    
    else
    {
        echo "link error";
        return null;
    }
        mysqli_close($link);  
}


//-------------------------------------------------------------------------
// opens a link to a server and selects database if $databaseName not empty

function createLink($host,$user,$password,$databaseName){
    
    if(!empty($databaseName)){
        $link = mysqli_connect($host,$user,$password,$databaseName);
    }
    else
    {
      $link = mysqli_connect($host,$user,$password);  
    }
    // error checking
if (!$link) {
    echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    return null;
    
}

// we have connection, celebrate and show host info
//echo "Weee: A proper connection!!<br>";

//echo "Host info: " . mysqli_get_host_info($link) ."<br>user:".$user."<br>";

return $link;
}






//-------------------------------------------------------------------------
//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// install stuff
//-------------------------------------------------------------------------
// inserts the user table into the selected database
function installTable($myDatabase,$host,$user,$password){
    
     $link =createLink($host,$user,$password,$myDatabase);
    
     // sql to create table userdata
$sql = "CREATE TABLE userdata (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
username VARCHAR(30) NOT NULL,
password VARCHAR(30) NOT NULL,
full_name VARCHAR(100),
email VARCHAR(100),
user_type VARCHAR(80),
reg_date TIMESTAMP
)";

if ($link->query($sql) === TRUE) {
    echo "Table created successfully<br><br>";
} else {
    echo "Error creating table: " . $link->error;
    exit;
}

// insert fake data
$myUserdata=generateUserData();

foreach($myUserdata as $userInfo){
    $sql = 'INSERT INTO userdata (username, password,full_name,email,user_type) VALUES ("'.

         $userInfo["USERNAME"].'","'.
            
         $userInfo["PASSWORD"].'","'.
         $userInfo["FULL_NAME"].'","'.
         $userInfo["EMAIL"].'","'.
         $userInfo["USER_TYPE"].'")';
 


 
 
if ($link->query($sql) === TRUE) {
    echo "New crazy cat lady: ".$userInfo["USERNAME"]." inserted successfully<br>";
} else {
    echo "Error: " . $sql . "<br>" . $link->error.'<br><br>';
}  

}

     
     
     
     

     mysqli_close($link);
}

//-------------------------------------------------------------------------
// shows databases on the selected server.. filtering the usual phpMyAdmin and xampp servers off
function ShowDatabases($host,$user,$password) {
    //$myDatabases[];
    // connect to localhost as root user
    $link =createLink("127.0.1","root","","");
// list databases

$sql="SHOW DATABASES"; //sql statement that .... shows databases

$result=mysqli_query($link,$sql); // send the query to the server

  
// process the result
while( $row = mysqli_fetch_row( $result ) ){
    // print_r($row); // what the * is comming back...
    
    // sort off unwanted databases so we do'nt install our table in existing by accident
        if (($row[0]!="information_schema") && ($row[0]!="mysql")&& ($row[0]!="performance_schema")&& ($row[0]!="phpmyadmin")) {
            // show the rest and add to list
            //echo $row[0].'<br>';
            $myDatabases[]=$row[0];
        }
    }

mysqli_close($link);

if(count($myDatabases)>0){
    return $myDatabases;
}
else
{
    return false;
}
    
    
}


//-------------------------------------------------------------------------
//generates bogus userdata

function generateUserData(){
    $nameArray=['Rikki Wardell','Grisel Boulware ',
'Yoshiko Morra','Rosemarie Egner','Colin Polinsky','Jake Lease','Fairy Tauber','Broderick Fils',
'Brigida Hazelrigg','Regan Brinkerhoff','Erika Cooney','Mitsue Sholes','Owen Trimarchi','Leonila Mcfarland','Brittny Mosquera','Brittani Laster','Filiberto Breeden','Claudio Straughan',
'Elicia Gourley','Angle Buckler','Margrett Schnieders','Ellena Homer','Georgeann Oiler','Erinn Clemmons','Sheldon Tumlin',
 'Arnetta Slaton','chloe Prude','Veola Rennie','Monty Boos','Monet Blanca','Suanne Zepeda','Cary Sugden','Aleshia Conlee',
  'Laquita Flake','rina Moreno','Delmy Verrill','Luanna Lees','Willetta Algarin','Hershel Dobbs','Germaine Ceniceros',
'Cinthia Levison','Jacqulyn Chinn','Daria Wu','Deshawn Seamon','Stepanie Wolter','Clemencia Hillen','Lila Ciulla','Terica Kolb',
'Kizzy Cothron','Myles Pieper'];

$userarray=[];

foreach ($nameArray as $user) {
    //generate username
    $arr = explode(' ',trim($user));
    $username=$arr[0];
    // random password
    $password= str_shuffle('123d45a678g9');
    
    $fullname=$user;
    
    $email=$username.'@somecorp.com';
    
    
    $typearray=['user','admin','guest'];
    $usertype=$typearray[rand(0, 2)];
    
    $userarray[]=["USERNAME"=>$username,"PASSWORD"=>$password,"FULL_NAME"=>$fullname,"EMAIL"=>$email,"USER_TYPE"=>$usertype];
    //echo "username: $username password: $password full name: $fullname Email: $email User type: $usertype<br>";
}
// insert admin user 
 $userarray[]=["USERNAME"=>"admin","PASSWORD"=>"1234","FULL_NAME"=>"admin","EMAIL"=>"admin@test.com","USER_TYPE"=>"admin"];
     
   
return $userarray;
}


